=== iStudioDesign Variation Inspector ===
Contributors: istudiodesign, mihaelpopovacki
Tags: woocommerce, variations, performance, attributes, analytics
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A powerful WooCommerce analysis tool that provides insights into variation counts, global attributes, and product performance. Includes CSV export, heavy/critical product detection, and detailed store statistics.

== Description ==

**iStudioDesign Variation Inspector** is an advanced WooCommerce analytics extension that scans your store and provides valuable insights into:

- Total number of variations across your entire store
- Total number of variable products
- Average variations per product
- Highest variation count per product
- Global attribute list overview
- Performance analytics (heavy & critical products)
- CSV export of all products with variation counts

Built for large WooCommerce stores and performance-critical setups.

Perfect for optimization, scaling, and diagnosing performance issues caused by excessive variation counts.

== Features ==

✔ **Full store analytics dashboard**  
✔ Total variation count  
✔ Variable product count  
✔ Average variations per product  
✔ Largest variation count on a single product  
✔ List of all global attributes  
✔ “Heavy” products (200+ variations)  
✔ “Critical” products (500+ variations)  
✔ **CSV export** of all products + variation counts  
✔ Lightweight & optimized (no impact on frontend)

== Installation ==

1. Upload the plugin folder `istudiodesign-variation-inspector` to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** menu in WordPress
3. Go to **WooCommerce → Variation Inspector** to access analytics

== Frequently Asked Questions ==

= Does this plugin affect website performance? =  
No — the plugin only runs queries when you open the Variation Inspector page. It does not load on the frontend.

= Can I export all product data? =  
Yes, a CSV export button is included.

= Does this modify products? =  
No. The plugin is read-only. It does not change or alter product data.

= Can this help diagnose slow WooCommerce stores? =  
Yes — sites with thousands of variations can experience performance issues.  
This tool identifies the problematic products instantly.

== Screenshots ==

1. Dashboard overview
2. Global attributes list
3. Performance analysis section
4. CSV export example

== Changelog ==

= 1.0.0 =
* Initial release
* Variation analytics dashboard
* Global attribute overview
* Heavy & critical product detection
* CSV export functionality
* Performance analysis module

== Upgrade Notice ==

= 1.0.0 =
Stable initial version.

