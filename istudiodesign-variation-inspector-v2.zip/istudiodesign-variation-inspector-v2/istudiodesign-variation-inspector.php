<?php
/**
 * Plugin Name: iStudioDesign – WooCommerce Variation Inspector
 * Description: Analitički alat za pregled ukupnog broja varijacija, globalnih atributa i najopterećenijih proizvoda u WooCommerce trgovini.
 * Version: 1.1.0
 * Author: Mihael Popovački – iStudioDesign
 * Author URI: https://istudiodesign.net
 * Text Domain: isd-variation-inspector
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Ne izravnom pristupu.
}

class ISD_Variation_Inspector {

    /**
     * Limit koliko proizvoda s najviše varijacija prikazujemo.
     *
     * @var int
     */
    protected $top_products_limit = 20;

    /**
     * Prag za "heavy" proizvod (puno varijacija).
     *
     * @var int
     */
    protected $heavy_threshold = 200;

    /**
     * Prag za "critical" proizvod (jako puno varijacija).
     *
     * @var int
     */
    protected $critical_threshold = 500;

    /**
     * Singleton instance.
     *
     * @var ISD_Variation_Inspector|null
     */
    protected static $instance = null;

    /**
     * Inicijalizacija.
     *
     * @return ISD_Variation_Inspector
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Konstruktor.
     */
    protected function __construct() {
        add_action( 'admin_init', array( $this, 'check_woocommerce_dependency' ) );
        add_action( 'admin_menu', array( $this, 'register_admin_page' ) );

        // CSV export.
        add_action( 'admin_post_isd_vi_export_csv', array( $this, 'handle_csv_export' ) );
    }

    /**
     * Provjera je li WooCommerce aktivan.
     */
    public function check_woocommerce_dependency() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
        }
    }

    /**
     * Notice ako WooCommerce nije aktivan.
     */
    public function woocommerce_missing_notice() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__( 'iStudioDesign – WooCommerce Variation Inspector zahtijeva aktivan WooCommerce plugin.', 'isd-variation-inspector' );
        echo '</p></div>';
    }

    /**
     * Registracija admin stranice.
     */
    public function register_admin_page() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        add_submenu_page(
            'woocommerce',
            __( 'Variation Inspector', 'isd-variation-inspector' ),
            __( 'Variation Inspector', 'isd-variation-inspector' ),
            'manage_woocommerce',
            'isd-variation-inspector',
            array( $this, 'render_admin_page' )
        );
    }

    /**
     * Render admin stranice.
     */
    public function render_admin_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Nemate dovoljne ovlasti za pristup ovoj stranici.', 'isd-variation-inspector' ) );
        }

        global $wpdb;

        // Statistika varijacija i distribucija po proizvodima.
        $stats = $this->get_variation_stats( $wpdb );

        $total_variations        = $stats['total_variations'];
        $total_variable_products = $stats['total_variable_products'];
        $max_variations          = $stats['max_variations'];
        $avg_variations          = $stats['avg_variations'];
        $heavy_count             = $stats['heavy_count'];
        $critical_count          = $stats['critical_count'];
        $distribution            = $stats['distribution']; // array stdClass (post_parent, variation_count)

        // Globalni atributi.
        $attributes_data = $this->get_global_attributes();

        // Top proizvodi po broju varijacija (sortirano po distribuciji).
        $top_products = $this->get_top_products_from_distribution( $distribution, $this->top_products_limit );

        // CSV export URL.
        $export_url = wp_nonce_url(
            admin_url( 'admin-post.php?action=isd_vi_export_csv' ),
            'isd_vi_export_csv',
            'isd_vi_nonce'
        );
        ?>
        <div class="wrap isd-variation-inspector-wrap">
            <h1><?php echo esc_html__( 'WooCommerce Variation Inspector', 'isd-variation-inspector' ); ?></h1>
            <p class="description">
                <?php echo esc_html__( 'Analitički pregled varijabilnih proizvoda, ukupnog broja varijacija i globalnih atributa u WooCommerce trgovini.', 'isd-variation-inspector' ); ?>
            </p>

            <style>
                .isd-variation-inspector-wrap .isd-badge {
                    display: inline-block;
                    padding: 2px 6px;
                    border-radius: 3px;
                    font-size: 11px;
                    font-weight: 600;
                    color: #fff;
                }
                .isd-badge-heavy { background-color: #f0ad4e; }
                .isd-badge-critical { background-color: #d9534f; }
                .isd-badge-ok { background-color: #5cb85c; }
            </style>

            <hr />

            <h2><?php echo esc_html__( 'Sažetak trgovine', 'isd-variation-inspector' ); ?></h2>
            <table class="widefat striped">
                <tbody>
                <tr>
                    <th scope="row"><?php echo esc_html__( 'Ukupan broj varijacija', 'isd-variation-inspector' ); ?></th>
                    <td><strong><?php echo esc_html( number_format_i18n( (int) $total_variations ) ); ?></strong></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__( 'Broj varijabilnih proizvoda', 'isd-variation-inspector' ); ?></th>
                    <td><strong><?php echo esc_html( number_format_i18n( (int) $total_variable_products ) ); ?></strong></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__( 'Prosječan broj varijacija po varijabilnom proizvodu', 'isd-variation-inspector' ); ?></th>
                    <td><strong><?php echo esc_html( number_format_i18n( (float) $avg_variations, 2 ) ); ?></strong></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__( 'Maksimalan broj varijacija na jednom proizvodu', 'isd-variation-inspector' ); ?></th>
                    <td><strong><?php echo esc_html( number_format_i18n( (int) $max_variations ) ); ?></strong></td>
                </tr>
                </tbody>
            </table>

            <h3 style="margin-top: 2em;"><?php echo esc_html__( 'Performance analitika', 'isd-variation-inspector' ); ?></h3>
            <table class="widefat striped">
                <tbody>
                <tr>
                    <th scope="row">
                        <?php
                        printf(
                            /* translators: %d: prag heavy proizvoda */
                            esc_html__( 'Broj "heavy" proizvoda (više od %d varijacija)', 'isd-variation-inspector' ),
                            (int) $this->heavy_threshold
                        );
                        ?>
                    </th>
                    <td><strong><?php echo esc_html( number_format_i18n( (int) $heavy_count ) ); ?></strong></td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        printf(
                            /* translators: %d: prag kritičnih proizvoda */
                            esc_html__( 'Broj "critical" proizvoda (više od %d varijacija)', 'isd-variation-inspector' ),
                            (int) $this->critical_threshold
                        );
                        ?>
                    </th>
                    <td><strong><?php echo esc_html( number_format_i18n( (int) $critical_count ) ); ?></strong></td>
                </tr>
                </tbody>
            </table>

            <p style="margin-top:1em;">
                <a href="<?php echo esc_url( $export_url ); ?>" class="button button-secondary">
                    <?php echo esc_html__( 'Preuzmi CSV izvještaj (svi proizvodi s varijacijama)', 'isd-variation-inspector' ); ?>
                </a>
            </p>

            <?php if ( ! empty( $attributes_data['items'] ) ) : ?>
                <h2 style="margin-top: 2.5em;"><?php echo esc_html__( 'Globalni atributi', 'isd-variation-inspector' ); ?></h2>
                <table class="widefat striped">
                    <thead>
                    <tr>
                        <th><?php echo esc_html__( 'Naziv atributa', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'Slug', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'Tip', 'isd-variation-inspector' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $attributes_data['items'] as $attribute ) : ?>
                        <tr>
                            <td><?php echo esc_html( $attribute['label'] ); ?></td>
                            <td><code><?php echo esc_html( $attribute['name'] ); ?></code></td>
                            <td><?php echo esc_html( $attribute['type'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p><?php echo esc_html__( 'Nema definiranih globalnih atributa.', 'isd-variation-inspector' ); ?></p>
            <?php endif; ?>

            <h2 style="margin-top: 2.5em;"><?php echo esc_html__( 'Proizvodi s najviše varijacija', 'isd-variation-inspector' ); ?></h2>
            <p class="description">
                <?php
                printf(
                    /* translators: %d: broj proizvoda */
                    esc_html__( 'Prikazano je prvih %d proizvoda s najvećim brojem varijacija.', 'isd-variation-inspector' ),
                    (int) $this->top_products_limit
                );
                ?>
            </p>

            <?php if ( ! empty( $top_products ) ) : ?>
                <table class="widefat striped">
                    <thead>
                    <tr>
                        <th><?php echo esc_html__( 'Proizvod', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'ID', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'Broj varijacija', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'Tip proizvoda', 'isd-variation-inspector' ); ?></th>
                        <th><?php echo esc_html__( 'Upozorenje', 'isd-variation-inspector' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $top_products as $row ) : ?>
                        <?php
                        $product_id   = (int) $row->post_parent;
                        $product_link = get_edit_post_link( $product_id );
                        $product      = wc_get_product( $product_id );

                        if ( ! $product ) {
                            continue;
                        }

                        $product_title = $product->get_name();
                        $product_type  = $product->get_type();
                        $severity      = $this->classify_severity( (int) $row->variation_count );
                        ?>
                        <tr>
                            <td>
                                <?php if ( $product_link ) : ?>
                                    <a href="<?php echo esc_url( $product_link ); ?>">
                                        <?php echo esc_html( $product_title ); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo esc_html( $product_title ); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( $product_id ); ?></td>
                            <td><strong><?php echo esc_html( number_format_i18n( (int) $row->variation_count ) ); ?></strong></td>
                            <td><?php echo esc_html( ucfirst( $product_type ) ); ?></td>
                            <td><?php echo wp_kses_post( $this->get_severity_badge( $severity ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p><?php echo esc_html__( 'Nisu pronađeni varijabilni proizvodi s varijacijama.', 'isd-variation-inspector' ); ?></p>
            <?php endif; ?>

            <p style="margin-top: 2em; font-size: 12px; color: #666;">
                <?php echo esc_html__( 'Napomena: Upiti za broj varijacija mogu potrajati kod vrlo velikih trgovina. Preporuča se koristiti alat izvan perioda najveće posjećenosti.', 'isd-variation-inspector' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Dohvat globalnih atributa.
     *
     * @return array
     */
    protected function get_global_attributes() {
        $items = array();

        if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
            $taxonomies = wc_get_attribute_taxonomies();

            if ( ! empty( $taxonomies ) ) {
                foreach ( $taxonomies as $attr ) {
                    $items[] = array(
                        'label' => isset( $attr->attribute_label ) ? $attr->attribute_label : $attr->attribute_name,
                        'name'  => isset( $attr->attribute_name ) ? 'pa_' . $attr->attribute_name : '',
                        'type'  => isset( $attr->attribute_type ) ? $attr->attribute_type : '',
                    );
                }
            }
        }

        return array(
            'count' => count( $items ),
            'items' => $items,
        );
    }

    /**
     * Izračun statistike varijacija i distribucije po proizvodima.
     *
     * @param wpdb $wpdb WordPress DB instance.
     * @return array
     */
    protected function get_variation_stats( $wpdb ) {
        $posts_table = $wpdb->posts;

        $sql = "
            SELECT post_parent, COUNT(*) AS variation_count
            FROM {$posts_table}
            WHERE post_type = 'product_variation'
              AND post_status NOT IN ( 'trash', 'auto-draft' )
              AND post_parent > 0
            GROUP BY post_parent
        ";

        $rows = $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        $total_variations        = 0;
        $total_variable_products = 0;
        $max_variations          = 0;
        $heavy_count             = 0;
        $critical_count          = 0;

        if ( ! empty( $rows ) ) {
            foreach ( $rows as $row ) {
                $count = (int) $row->variation_count;

                $total_variations        += $count;
                $total_variable_products++;
                $max_variations = max( $max_variations, $count );

                $severity = $this->classify_severity( $count );
                if ( 'critical' === $severity ) {
                    $critical_count++;
                } elseif ( 'heavy' === $severity ) {
                    $heavy_count++;
                }
            }
        }

        $avg_variations = 0;
        if ( $total_variable_products > 0 ) {
            $avg_variations = $total_variations / $total_variable_products;
        }

        return array(
            'total_variations'        => $total_variations,
            'total_variable_products' => $total_variable_products,
            'max_variations'          => $max_variations,
            'avg_variations'          => $avg_variations,
            'heavy_count'             => $heavy_count,
            'critical_count'          => $critical_count,
            'distribution'            => $rows,
        );
    }

    /**
     * Dohvat top proizvoda iz distribucije.
     *
     * @param array $distribution Array stdClass (post_parent, variation_count).
     * @param int   $limit        Limit.
     * @return array
     */
    protected function get_top_products_from_distribution( $distribution, $limit = 20 ) {
        if ( empty( $distribution ) ) {
            return array();
        }

        $limit = (int) $limit;
        if ( $limit <= 0 ) {
            $limit = 20;
        }

        // Sortiramo po broju varijacija (DESC).
        usort(
            $distribution,
            function ( $a, $b ) {
                $av = (int) $a->variation_count;
                $bv = (int) $b->variation_count;

                if ( $av === $bv ) {
                    return 0;
                }

                return ( $av > $bv ) ? -1 : 1;
            }
        );

        return array_slice( $distribution, 0, $limit );
    }

    /**
     * Klasifikacija "severity" za broj varijacija.
     *
     * @param int $count Broj varijacija.
     * @return string 'ok'|'heavy'|'critical'
     */
    protected function classify_severity( $count ) {
        $count = (int) $count;

        if ( $count >= $this->critical_threshold ) {
            return 'critical';
        }

        if ( $count >= $this->heavy_threshold ) {
            return 'heavy';
        }

        return 'ok';
    }

    /**
     * HTML badge za severity.
     *
     * @param string $severity Severity string.
     * @return string
     */
    protected function get_severity_badge( $severity ) {
        switch ( $severity ) {
            case 'critical':
                return '<span class="isd-badge isd-badge-critical">' . esc_html__( 'Critical', 'isd-variation-inspector' ) . '</span>';
            case 'heavy':
                return '<span class="isd-badge isd-badge-heavy">' . esc_html__( 'Heavy', 'isd-variation-inspector' ) . '</span>';
            default:
                return '<span class="isd-badge isd-badge-ok">' . esc_html__( 'OK', 'isd-variation-inspector' ) . '</span>';
        }
    }

    /**
     * CSV export handler.
     */
    public function handle_csv_export() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Nemate dovoljne ovlasti za pristup ovoj stranici.', 'isd-variation-inspector' ) );
        }

        if ( ! isset( $_GET['isd_vi_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['isd_vi_nonce'] ) ), 'isd_vi_export_csv' ) ) {
            wp_die( esc_html__( 'Neispravan sigurnosni token.', 'isd-variation-inspector' ) );
        }

        global $wpdb;

        $stats        = $this->get_variation_stats( $wpdb );
        $distribution = $stats['distribution'];

        if ( empty( $distribution ) ) {
            wp_die( esc_html__( 'Nema podataka za izvoz.', 'isd-variation-inspector' ) );
        }

        // Sortiramo po broju varijacija (DESC).
        usort(
            $distribution,
            function ( $a, $b ) {
                $av = (int) $a->variation_count;
                $bv = (int) $b->variation_count;

                if ( $av === $bv ) {
                    return 0;
                }

                return ( $av > $bv ) ? -1 : 1;
            }
        );

        // CSV headeri.
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=istudiodesign-variation-inspector.csv' );

        $output = fopen( 'php://output', 'w' );

        // Header row.
        fputcsv(
            $output,
            array(
                'product_id',
                'product_title',
                'variation_count',
                'product_type',
                'severity',
            )
        );

        foreach ( $distribution as $row ) {
            $product_id = (int) $row->post_parent;
            $product    = wc_get_product( $product_id );

            if ( ! $product ) {
                continue;
            }

            $title    = $product->get_name();
            $type     = $product->get_type();
            $severity = $this->classify_severity( (int) $row->variation_count );

            fputcsv(
                $output,
                array(
                    $product_id,
                    $title,
                    (int) $row->variation_count,
                    $type,
                    $severity,
                )
            );
        }

        fclose( $output );
        exit;
    }
}

ISD_Variation_Inspector::get_instance();
